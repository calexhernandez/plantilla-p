import socketio

SERVER_URL = 'http://socket-handle-tests.amaditaplayground.com:30008'  # Cambia por tu URL y puerto

# Credenciales para autenticación
username = "employees.consultor"
password = "gVh6#1TSyPt2"

# Crear cliente Socket.IO
sio = socketio.Client()


# Evento al conectarse
@sio.event
def connect():
    print('Conectado al servidor')
    sio.emit('chat message', 'Hola Mundo desde servidor de integracion')


# Evento al desconectarse
@sio.event
def disconnect():
    print('Desconectado del servidor')


@sio.event
def connect_error(data):
    print('Error de conexión:', data)


sio.connect(
    SERVER_URL,
    auth={'username': username, 'password': password}
)

sio.wait()