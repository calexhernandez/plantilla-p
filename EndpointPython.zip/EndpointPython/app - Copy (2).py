import socketio

# Create a Socket.IO client
sio = socketio.Client()

@sio.event
def connect():
    print("✅ Connected to server")

    # Send credentials
    sio.emit("auth", {
        "username": "employees.consultor",
        "password": "gVh6#1TSyPt2"
    })

@sio.on("auth_response")
def on_auth_response(data):
    print("🔐 Auth response:", data)

    if data.get("status") == "ok":
        # Send order data if auth was successful
        sio.emit("send order", {
            "orderId": 12345,
            "note": "Hello from Python client"
        })

@sio.on("sent order")
def on_sent_order(data):
    print("📦 Sent order response:", data)
    sio.disconnect()

@sio.event
def connect_error(data):
    print("❌ Connection failed:", data)

@sio.event
def disconnect():
    print("❌ Disconnected from server")

# Connect to the server
sio.connect("http://socket-handle-tests.amaditaplayground.com:30008", transports=["websocket"])
sio.wait()